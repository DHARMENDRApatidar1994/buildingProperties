import React from 'react'
import ForInvestmentsec1 from '../component/forinvestment/ForInvestmentsec1'
import Forrentsec3 from '../component/forrent/Forrentsec3'

const ForInvestment = () => {
  return (
    <div>
        <ForInvestmentsec1/>
        <Forrentsec3/>
    </div>
  )
}

export default ForInvestment