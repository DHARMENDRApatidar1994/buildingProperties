import React from 'react'
import ForRentsec1 from '../component/forrent/ForRentsec1'
import Forrentsec3 from '../component/forrent/Forrentsec3'

const ForRent = () => {
  return (
    <div>
        <ForRentsec1/>
       
        <Forrentsec3/>
    </div>
  )
}

export default ForRent