import React from 'react'
import ForSalesec1 from '../component/forsale/ForSalesec1'
import Forrentsec3 from '../component/forrent/Forrentsec3'

const ForSale = () => {
  return (
    <div>
        <ForSalesec1/> 
        <Forrentsec3/>
        
    </div>
  )
}

export default ForSale