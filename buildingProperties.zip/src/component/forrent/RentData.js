export const rent = [
    {
        image:"featuredimg2.jpg",
        price:"6,250",
        title:"Bunglow for rent",
        address:"Leeds city center",
        bed:"4",
        bath:"4",
        furniture:"furnished",
       
    },
    {
        image:"featuredimg3.jpg",
        price:"850",
        title:"Penthouse",
        address:"Menchester city",
        bed:"3",
        bath:"2",
        furniture:"semi-furnished",
      
    },
    {
        image:"featuredimg1.webp",
        price:"6,25",
        title:"Bunglow",
        address:"Leeds city center",
        bed:"3",
        bath:"2",
        furniture:"semi-furnished",
    },
    {
        image:"sale4.png",
        price:"345",
        title:"Bunglow",
        address:"Derby side country ",
        bed:"3",
        bath:"2",
        furniture:"semi-furnished",
    },
    {
        image:"sale5.png",
        price:"645",
        title:"semi detached house",
        address:"Southfield Road, Oxford OX4",
        bed:"3",
        bath:"2",
        furniture:"semi-furnished",
    },
    {
        image:"sale6.png",
        price:"200",
        title:"penthouse",
        address:"Menchester city",
        bed:"3",
        bath:"2",
        furniture:"semi-furnished",
    },
    {
        image:"sale7.png",
        price:"240",
        title:"Bunglow",
        address:"Leeds city center",
        bed:"3",
        bath:"2",
        furniture:"semi-furnished",
    },
    {
        image:"sale8.png",
        price:"125",
        title:"penthouse ",
        address:"Menchester city",
        bed:"3",
        bath:"2",
        furniture:"semi-furnished",
    },
    {
        image:"sale9.png",
        price:"200",
        
        title:"Semi detached house",
        address:"Southfield Road, Oxford OX4",
        bed:"3",
        bath:"2",
        furniture:"semi-furnished",
    },
   
   
   
   
   

]