import React from 'react'

const Forrentsec3 = () => {
  return (
    <div>
        <div className='forrentsignin'>
            <h3>Sign in to enjoy much more</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint quaerat laudantium est, ea qui adipisci nulla doloremque illo. Obcaecati eligendi labore harum eum id, consequatur vel neque laboriosam impedit pariatur.</p>
            <button>+ sign in</button>
        </div>
    </div>
  )
}

export default Forrentsec3